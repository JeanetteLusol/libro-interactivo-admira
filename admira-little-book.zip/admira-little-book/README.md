# Admira · Little Book (landing interactiva)

Abre `index.html` en cualquier navegador moderno (Chrome, Edge, Safari, Firefox). No necesita instalación ni servidor.
Para publicarla, sube la carpeta completa a cualquier hosting estático (Netlify, Vercel, GitHub Pages, el servidor de la web…).

## Estructura
- `index.html` — todo el contenido: portada, textos de cada página e ilustraciones (SVG). Cada página está marcada con un comentario `<!-- ===== Página N ... ===== -->`.
- `css/styles.css` — estilos y animaciones. Las animaciones de cada página empiezan por `.s1-`, `.s2-`… (número de página). Las animaciones al tocar están al final (`.tA` / `.tB`).
- `js/app.js` — navegación, paso de páginas, valores desbloqueados y colores del fondo por página (`THEMES`).
- `assets/` — logo blanco de la cabecera y foto de la casa.

## Cambios habituales
- **Textos**: busca la frase en `index.html` y cámbiala.
- **Color de fondo de una página**: edita su línea en `THEMES` dentro de `js/app.js`.
- **Foto**: reemplaza `assets/garden.jpg` por otra con el mismo nombre.
- La tipografía (Roboto) se carga desde Google Fonts; sin conexión se usa la fuente del sistema.
