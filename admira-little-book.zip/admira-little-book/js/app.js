/* Admira · Little Book — lógica de la landing (JavaScript sin dependencias).
 * - Página 0 = portada cerrada; 1..17 = pliegos del libro.
 * - THEMES: colores del fondo para cada página [inicio, medio, final del degradado].
 * - VALUES: los 10 valores (nombre + icono) que se desbloquean en las páginas 6..15.
 */
(function () {
  var LAST = 17;
  var THEMES = [
    ['#5fa452', '#4cc27a', '#36dca8'], // 0 portada
    ['#5a9f3c', '#49b87a', '#2fcf9f'], // 1 Porque el Little Book
    ['#2d6447', '#2a876a', '#23a98a'], // 2 Qué es Admira
    ['#6aa83a', '#86c24a', '#3bb87a'], // 3 Foto
    ['#3f9a5a', '#33b38a', '#2bbfc0'], // 4 Misión
    ['#5fa452', '#7cc36a', '#3fd6a4'], // 5 Valores
    ['#4fa86a', '#55bf9a', '#46c4c9'], // 6 Diversidad
    ['#5c9e45', '#82bc4f', '#3fcf9a'], // 7 Igualdad
    ['#2f7a2e', '#4e9f3a', '#7cc048'], // 8 Ecología
    ['#78b23a', '#a3c83c', '#d9c94a'], // 9 Optimismo
    ['#4f9e4a', '#3fb98a', '#36c6d0'], // 10 Colaboración
    ['#3b7a4a', '#3e9a72', '#4ab58f'], // 11 Responsabilidad
    ['#4a8f2e', '#5fae3f', '#2fc39a'], // 12 Ejecutar
    ['#3e8f6a', '#2fa7a0', '#3dbfd8'], // 13 Curiosidad
    ['#4fae7a', '#6fd0b2', '#93e2d0'], // 14 Transparencia
    ['#6a9e55', '#86b87a', '#80cfac'], // 15 Humildad
    ['#4c9a3c', '#3fc07c', '#2fd6b0'], // 16 Conclusión
    ['#5fa452', '#4cc27a', '#36dca8']  // 17 Final
  ];
  var VALUES = ['Diversidad', 'Igualdad', 'Ecología', 'Optimismo', 'Colaboración', 'Responsabilidad', 'Capacidad de ejecutar', 'Curiosidad', 'Transparencia', 'Humildad'];
  var FIRST_VALUE_PAGE = 6;

  var $ = function (s) { return document.querySelector(s); };
  var root = $('#root'), book = $('#book'), cover = $('#cover');
  var leafN = $('#leaf-next'), leafP = $('#leaf-prev');
  var parts = Array.prototype.slice.call(document.querySelectorAll('[data-s]'));
  var badgeEls = Array.prototype.slice.call(document.querySelectorAll('.badge'));

  var st = { page: 0, opened: false, busy: false, found: [], last: -1, taps: 0, celebrated: false };

  function unlock(p) {
    var k = p - FIRST_VALUE_PAGE;
    st.last = -1;
    if (k >= 0 && k < 10 && st.found.indexOf(k) < 0) { st.found.push(k); st.last = k; }
  }

  function applyTap() {
    document.querySelectorAll('[data-tap]').forEach(function (el) {
      el.classList.remove('tA', 'tB', 'tapped', 'h1', 'h2', 'h3', 'h4');
      if (st.taps > 0) {
        el.classList.add(st.taps % 2 ? 'tA' : 'tB', 'tapped');
        for (var h = 1; h <= Math.min(st.taps, 4); h++) el.classList.add('h' + h);
      }
    });
  }

  function render() {
    var p = st.page, th = THEMES[p] || THEMES[0];
    root.style.setProperty('--c1', th[0]); root.style.setProperty('--c2', th[1]); root.style.setProperty('--c3', th[2]);
    parts.forEach(function (el) { var show = +el.dataset.s === p; if (el.hidden === show) el.hidden = !show; });
    book.classList.toggle('closed', !st.opened); book.classList.toggle('open', st.opened);
    $('#nav-prev').disabled = p <= 1;
    $('#nav-next').disabled = p === 0 || p >= LAST;
    $('#corner-l').hidden = !(p > 1 && p !== 3);
    $('#corner-r').hidden = !(p >= 1 && p < LAST && p !== 3);
    $('#hud-lbl').textContent = p === 0 ? 'Portada' : ((p < 10 ? '0' : '') + p + ' / ' + LAST);
    $('#hud-fill').style.width = Math.round(p / LAST * 100) + '%';
    $('#hud-found').textContent = st.found.length;
    $('#fin-found').textContent = st.found.length;
    $('#fin-missing').hidden = st.found.length >= 10;
    badgeEls.forEach(function (b, k) {
      var on = st.found.indexOf(k) >= 0;
      b.className = 'badge' + (on ? ' on' + (k === st.last ? ' pop' : '') : '');
      b.setAttribute('aria-label', on ? 'Ir al valor ' + VALUES[k] : 'Ir al valor ' + (k + 1) + ', aún sin descubrir');
      b.querySelector('.bd-tip').textContent = on ? VALUES[k] : 'Valor ' + (k + 1) + ' por descubrir';
    });
    $('#cta').hidden = st.celebrated;
    $('#welcome').hidden = !st.celebrated;
    $('#you').setAttribute('class', st.celebrated ? 'you on' : 'you');
    applyTap();
  }

  function openTo(target) {
    if (st.busy) return;
    st.busy = true; st.opened = true; st.page = target; st.taps = 0; unlock(target);
    cover.classList.add('open');
    render();
    setTimeout(function () { st.busy = false; cover.hidden = true; }, 1150);
  }

  function flipTo(target) {
    var p = st.page;
    if (st.busy || target === p || target < 1 || target > LAST) return;
    st.busy = true;
    var leaf = target > p ? leafN : leafP;
    leaf.hidden = false;
    setTimeout(function () { st.page = target; st.taps = 0; unlock(target); render(); }, 400);
    setTimeout(function () { leaf.hidden = true; st.busy = false; }, 840);
  }

  function next() { if (st.page === 0) openTo(1); else flipTo(st.page + 1); }
  function prev() { flipTo(st.page - 1); }

  function restart() {
    if (st.busy) return;
    st.page = 0; st.opened = false; st.taps = 0; st.celebrated = false;
    cover.classList.remove('open'); cover.hidden = false;
    render();
  }

  // eventos
  cover.addEventListener('click', function () { openTo(1); });
  document.querySelectorAll('[data-nav]').forEach(function (b) {
    b.addEventListener('click', function () { b.dataset.nav === 'next' ? next() : prev(); });
  });
  document.querySelectorAll('[data-tap]').forEach(function (b) {
    b.addEventListener('click', function () { st.taps++; applyTap(); });
  });
  badgeEls.forEach(function (b, k) {
    b.addEventListener('click', function () {
      if (st.page === 0) openTo(k + FIRST_VALUE_PAGE); else flipTo(k + FIRST_VALUE_PAGE);
    });
  });
  $('#restart').addEventListener('click', restart);
  $('#cta').addEventListener('click', function () {
    st.celebrated = true; render();
    var c = $('#confetti'); c.hidden = false;
    setTimeout(function () { c.hidden = true; }, 4200);
  });

  // inclinación 3D del libro y parallax del fondo con el ratón
  var raf = 0;
  window.addEventListener('mousemove', function (e) {
    if (raf) return;
    raf = requestAnimationFrame(function () {
      raf = 0;
      var r = document.documentElement;
      r.style.setProperty('--mx', (e.clientX / window.innerWidth - 0.5).toFixed(3));
      r.style.setProperty('--my', (e.clientY / window.innerHeight - 0.5).toFixed(3));
    });
  }, { passive: true });

  render();
})();
